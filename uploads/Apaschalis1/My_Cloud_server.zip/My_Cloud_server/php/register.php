<?php

 include 'configfile.php';

$First_Name = $_POST['firstName'];
$Last_Name = $_POST['lastName'];
$Gender = $_POST['gender'];
$Username = $_POST['Username'];
$Confirm_Email = $_POST['confirmEmail'];
$Confirm_Password = $_POST['confirmPassword'];

$query = mysql_query("SELECT * FROM users WHERE Username='$Username' AND Confirm_Email='$Confirm_Email'");
 $numberRows = mysql_num_rows($query);
 
 if ($numberRows != 0)
 {
   while($rows = mysql_fetch_assoc($query))
   {
   $dbUsername = $rows['Username'];
   $dbEmail = $rows['Confirm_Email'];
    echo "Sorry you have already registered";
   }
 }  
   else{
   $add = "INSERT INTO users (First_Name,Last_Name,Gender,Username,Confirm_Email,Confirm_Password) VALUES ('$First_Name','$Last_Name','$Gender','$Username','$Confirm_Email','$Confirm_Password')";
   $res = mysql_query($add); }
   
   if($res)
   {
     echo "You have successfully registered";
	 mkdir($_SERVER['DOCUMENT_ROOT'] . "/My_Cloud_server/uploads/" .$Username, 0777);
   }
   
   else {
   die ("Error, Registration failed: " .mysql_error());}



?>