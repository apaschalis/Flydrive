<?php

session_start();

$arr = array();

 $dir = '../uploads/'.$_SESSION['username'].'/';
if (file_exists($dir)) {
    if ($dh = opendir($dir)) {
        while (($file = readdir($dh)) !== false) {

            if ($file!="."&&$file!="..") {
            $arr = $file;
             //echo "filename:".$file."<br />";
            }

        }
        //print_r($arr);
        closedir($dh);
        echo json_encode('filename',$arr);
    }else{
        echo "empty";
    }
}else{
    echo "no directory";
}



?>