<?php
      include 'configfile.php';

     $username = $_POST['username'];
	 $password = $_POST['password'];
	if ($username && $password)
	{
	 $query = mysql_query("SELECT * FROM users WHERE username='$username'");

	 
	 if (mysql_num_rows($query) != 0)
		{ 
		   $row = mysql_fetch_assoc($query);
		   $fdbusername = $row['Username'];
		   $fdbpassword = $row['Confirm_Password'];
		 }
		 
		  else 
		die("Error, Incorrect username has been entered");
		
		 if ($username == $fdbusername && $password == $fdbpassword)
		 {
		   session_start();
		   
		   $_SESSION['username']=$username ;
		   
		   header('Location: ../User Interface.html');
		 }
		  else 
		       echo "Error, Incorrect password has been entered";
	
	}
   
	
	

?>